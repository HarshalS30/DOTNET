﻿using Microsoft.Extensions.Configuration;

namespace Employee
{

    internal class Program
    {
        private static IConfiguration _iconfiguration;

        /*Usage in Main:

        In the Main method of your application, you call GetAppSettingsFile to read the database connection string 
        from the configuration file. Then, you call PrintProduct to retrieve and display the data from the "Product" table.*/
        static void Main(string[] args)
        {
            GetAppSettingsFile();
            PrintProduct();
        }
        static void GetAppSettingsFile()
        {
            var builder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("Appsettings.json", optional: false, reloadOnChange: true);
            _iconfiguration = builder.Build();//where the file is we are there
        }
        static void PrintProduct()
        {
            Productlayer obj = new Productlayer(_iconfiguration);
            obj.Products();


        }
    }

}